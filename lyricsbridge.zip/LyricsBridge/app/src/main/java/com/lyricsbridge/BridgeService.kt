package com.lyricsbridge

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * Membaca lagu yang sedang diputar (Spotify) lewat MediaSession, mengambil lirik ber-timestamp
 * dari LRCLIB, lalu mengirimnya ke add-on LyricsPlus lewat WebSocket (/connect) sebagai scriptevent.
 */
class BridgeService : NotificationListenerService() {
    companion object {
        const val PORT = 8974
        const val CHUNK = 300 // panjang maksimal isi satu perintah lp:l; kecilkan jika lirik terpotong
    }

    private class Track(val id: String, val title: String, val artist: String, val dur: Double) {
        @Volatile var chunks: List<String>? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val clients = AtomicInteger(0)
    private var server: WebSocketServer? = null
    private var current: Track? = null
    private var count = 0

    private val ticker = object : Runnable {
        override fun run() {
            try { tick() } catch (_: Exception) {}
            handler.postDelayed(this, 1000)
        }
    }

    override fun onListenerConnected() {
        shutdown()
        State.load(this)
        clients.set(0); State.clients = 0
        server = object : WebSocketServer(InetSocketAddress("127.0.0.1", PORT)) {
            override fun onOpen(conn: WebSocket, h: ClientHandshake) {
                State.clients = clients.incrementAndGet()
                handler.post { if (State.sendOn) current?.chunks?.forEach { this@BridgeService.send(conn, it) } }
            }
            override fun onClose(conn: WebSocket?, code: Int, reason: String?, remote: Boolean) {
                State.clients = clients.decrementAndGet().coerceAtLeast(0)
            }
            override fun onMessage(conn: WebSocket?, message: String?) {}
            override fun onError(conn: WebSocket?, ex: Exception?) { if (conn == null) State.serverUp = false }
            override fun onStart() { State.serverUp = true }
        }.also { it.isReuseAddr = true; it.start() }
        handler.post(ticker)
    }

    override fun onListenerDisconnected() = shutdown()
    override fun onDestroy() { shutdown(); super.onDestroy() }

    private fun shutdown() {
        handler.removeCallbacks(ticker)
        try { server?.stop(300) } catch (_: Exception) {}
        server = null
        State.serverUp = false; State.clients = 0
    }

    // ---------- kirim ke Minecraft ----------
    private fun send(c: WebSocket, cmd: String) {
        val j = JSONObject()
            .put("header", JSONObject()
                .put("version", 1)
                .put("requestId", UUID.randomUUID().toString())
                .put("messageType", "commandRequest")
                .put("messagePurpose", "commandRequest"))
            .put("body", JSONObject()
                .put("origin", JSONObject().put("type", "player"))
                .put("commandLine", cmd)
                .put("version", 1))
        try { c.send(j.toString()) } catch (_: Exception) {}
    }

    private fun broadcast(cmd: String) { server?.connections?.forEach { send(it, cmd) } }

    // ---------- loop utama (tiap 1 detik) ----------
    private fun pickController(): MediaController? {
        val msm = getSystemService(MediaSessionManager::class.java)
        val list = try {
            msm.getActiveSessions(ComponentName(this, BridgeService::class.java))
        } catch (_: SecurityException) { return null }
        return list.firstOrNull { it.packageName == "com.spotify.music" }
            ?: list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
    }

    private fun tick() {
        if (State.refetch) { State.refetch = false; current = null }
        val c = pickController()
        val md = c?.metadata
        val st = c?.playbackState
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
        if (c == null || md == null || st == null || title == null) {
            State.title = ""; State.playing = false
            return
        }
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION) / 1000.0
        val playing = st.state == PlaybackState.STATE_PLAYING
        var pos = st.position / 1000.0
        if (playing) pos += (SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed / 1000.0

        State.title = title; State.artist = artist; State.dur = dur; State.pos = pos; State.playing = playing

        val id = "%08x".format((artist + "\u0000" + title).hashCode())
        if (current?.id != id) {
            State.art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            State.lyricsState = 1; State.lyrics = ""
            val t = Track(id, title, artist, dur)
            current = t
            io.execute {
                val lines = fetchLrc(t)?.let { parseLrc(it) } ?: emptyList()
                val text = lines.filter { it.second.isNotEmpty() }.joinToString("\n") { it.second }
                t.chunks = buildChunks(id, lines)
                handler.post {
                    if (current === t) {
                        State.lyrics = text
                        State.lyricsState = if (text.isEmpty()) 3 else 2
                        if (State.sendOn) t.chunks?.forEach { broadcast(it) }
                    }
                }
            }
        }
        val t = current ?: return
        val ch = t.chunks ?: return // tunggu lirik selesai dicari dulu
        if (!State.sendOn) return
        if (++count % 20 == 0) ch.forEach { broadcast(it) } // kirim ulang berkala (jaga-jaga add-on ke-reload)
        val sendPos = (pos + State.offset).coerceAtLeast(0.0)
        broadcast("scriptevent lp:t $id|${if (playing) 1 else 0}|${"%.2f".format(Locale.US, sendPos)}|" +
            "${"%.2f".format(Locale.US, dur)}|${ch.size}|${title.replace("|", "/")}|${artist.replace("|", "/")}")
    }

    // ---------- lirik (LRCLIB) ----------
    private fun http(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "LyricsBridge/1.0")
        if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
    } catch (_: Exception) { null }

    private fun synced(o: JSONObject) = if (o.isNull("syncedLyrics")) "" else o.getString("syncedLyrics")

    private fun fetchLrc(t: Track): String? {
        val a = URLEncoder.encode(t.artist, "UTF-8"); val n = URLEncoder.encode(t.title, "UTF-8")
        try {
            http("https://lrclib.net/api/get?artist_name=$a&track_name=$n&duration=${t.dur.toInt()}")?.let {
                val s = synced(JSONObject(it)); if (s.isNotBlank()) return s
            }
            http("https://lrclib.net/api/search?track_name=$n&artist_name=$a")?.let {
                val arr = JSONArray(it)
                for (i in 0 until arr.length()) { val s = synced(arr.getJSONObject(i)); if (s.isNotBlank()) return s }
            }
        } catch (_: Exception) {}
        return null
    }

    private fun parseLrc(lrc: String): List<Pair<Double, String>> {
        val tag = Regex("\\[(\\d+):(\\d+(?:\\.\\d+)?)\\]")
        val out = ArrayList<Pair<Double, String>>()
        for (line in lrc.lines()) {
            val tags = tag.findAll(line).toList()
            if (tags.isEmpty()) continue
            // baris kosong sengaja dipertahankan: add-on memakainya sebagai penanda akhir baris/jeda instrumental
            val text = line.substring(tags.last().range.last + 1).trim().replace(";;", ";")
            for (m in tags) out += (m.groupValues[1].toInt() * 60 + m.groupValues[2].toDouble()) to text
        }
        return out.sortedBy { it.first }
    }

    private fun buildChunks(id: String, lines: List<Pair<Double, String>>): List<String> {
        val groups = ArrayList<String>(); val sb = StringBuilder()
        for ((time, text) in lines) {
            val p = "${"%.2f".format(Locale.US, time)}~$text"
            if (sb.isNotEmpty() && sb.length + p.length + 2 > CHUNK) { groups += sb.toString(); sb.setLength(0) }
            if (sb.isNotEmpty()) sb.append(";;")
            sb.append(p)
        }
        if (sb.isNotEmpty()) groups += sb.toString()
        return groups.mapIndexed { k, g -> "scriptevent lp:l $id|$k|${groups.size}|$g" }
    }
}
