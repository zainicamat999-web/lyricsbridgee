package com.lyricsbridge

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private val GREEN = Color.parseColor("#4CD964")
    private val AMBER = Color.parseColor("#FFC107")
    private val RED = Color.parseColor("#FF5252")
    private val GRAY = Color.parseColor("#9AA0A6")
    private val connectCmd: String get() = "/connect 127.0.0.1:${BridgeService.PORT}"

    private lateinit var ck: List<TextView>
    private lateinit var stN: TextView
    private lateinit var stS: TextView
    private lateinit var stM: TextView
    private lateinit var art: ImageView
    private lateinit var npTitle: TextView
    private lateinit var npArtist: TextView
    private lateinit var npTime: TextView
    private lateinit var npBar: ProgressBar
    private lateinit var offLabel: TextView
    private lateinit var lyricsView: TextView
    private lateinit var pages: List<View>
    private lateinit var tabs: List<TextView>

    // ---------- helper tampilan ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat(); setColor(color)
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun label(t: String, sp: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = sp; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun card(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(16))
        background = round(0x22FFFFFF, 18, 0x33FFFFFF)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
        addView(label(title.uppercase(), 11f, GRAY).apply { letterSpacing = 0.1f; setPadding(0, 0, 0, dp(8)) })
    }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 13f
        background = round(0x33FFFFFF, 14, 0x44FFFFFF)
        stateListAnimator = null
        setOnClickListener { onClick() }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEachIndexed { i, x ->
            addView(x, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) marginStart = dp(8) })
        }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    }

    private fun page(title: String, vararg cards: View): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(18), dp(14), dp(8))
            addView(label(title, 22f, Color.WHITE, true).apply { setPadding(dp(4), 0, 0, dp(14)) })
        }
        cards.forEach { col.addView(it) }
        return ScrollView(this).apply { addView(col) }
    }

    private fun mark(tv: TextView, done: Boolean, text: String) {
        tv.text = (if (done) "✔  " else "○  ") + text
        tv.setTextColor(if (done) GREEN else GRAY)
    }

    private fun dot(tv: TextView, ok: Boolean?, text: String) {
        val col = when (ok) { true -> GREEN; false -> RED; null -> AMBER }
        val s = SpannableString("●  $text")
        s.setSpan(ForegroundColorSpan(col), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        tv.text = s
    }

    private fun copy(text: String, msg: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("lp", text))
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun mmss(sec: Double): String {
        val s = sec.toInt().coerceAtLeast(0)
        return "%d:%02d".format(s / 60, s % 60)
    }

    // ---------- susun layar ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        State.load(this)
        window.statusBarColor = Color.parseColor("#0E0F12")
        window.navigationBarColor = Color.parseColor("#0E0F12")

        // === Beranda ===
        ck = List(4) { label("", 14f).apply { setPadding(0, dp(4), 0, dp(4)) } }
        val cQuick = card("Mulai cepat").also { c -> ck.forEach { c.addView(it) } }

        stN = label(""); stS = label(""); stM = label("")
        val cStatus = card("Status").also { c ->
            listOf(stN, stS, stM).forEach { it.setPadding(0, dp(3), 0, dp(3)); c.addView(it) }
            c.addView(row(
                btn("Izin notifikasi") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
                btn("Salin /connect") { copy(connectCmd, "Perintah disalin, tempel di chat Minecraft") }))
        }

        art = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = round(0x22FFFFFF, 12); clipToOutline = true
        }
        npTitle = label("(belum ada lagu)", 17f, Color.WHITE, true)
        npArtist = label("Putar lagu di Spotify", 13f, GRAY)
        npTime = label("0:00 / 0:00", 12f, GRAY)
        npBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL
            addView(npTitle); addView(npArtist)
        }
        val cNow = card("Sedang diputar").also { c ->
            c.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                addView(art, LinearLayout.LayoutParams(dp(64), dp(64)))
                addView(info, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(14) })
            })
            c.addView(npBar, LinearLayout.LayoutParams(-1, dp(8)).apply { topMargin = dp(14) })
            c.addView(npTime)
            c.addView(row(btn("Cari lirik ulang") { State.refetch = true }))
        }

        // === Lirik ===
        offLabel = label("", 14f)
        fun bump(d: Double) {
            State.offset = Math.round((State.offset + d) * 10) / 10.0
            State.save(this)
        }
        val cSync = card("Sinkron lirik").also { c ->
            c.addView(offLabel)
            c.addView(row(
                btn("−0.5 d") { bump(-0.5) },
                btn("Reset") { State.offset = 0.0; State.save(this) },
                btn("+0.5 d") { bump(0.5) }))
            c.addView(label("Lirik terlalu lambat? tekan +. Terlalu cepat? tekan −.", 12f, GRAY)
                .apply { setPadding(0, dp(8), 0, 0) })
        }
        lyricsView = label("Belum ada lirik.", 14f, GRAY).apply { minHeight = dp(160); setTextIsSelectable(true) }
        val cLyr = card("Lirik lengkap").also { c ->
            c.addView(lyricsView)
            c.addView(row(
                btn("Salin lirik") { copy(State.lyrics, "Lirik disalin") },
                btn("Bagikan") {
                    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, State.lyrics) }
                    startActivity(Intent.createChooser(i, null))
                }))
        }

        // === Setelan ===
        val sw = Switch(this).apply {
            text = "Kirim lirik ke Minecraft"; setTextColor(Color.WHITE); isChecked = State.sendOn
            setOnCheckedChangeListener { _, v -> State.sendOn = v; State.save(this@MainActivity) }
        }
        val cSet = card("Pengaturan").also { c ->
            c.addView(sw)
            c.addView(label("Matikan untuk berhenti menampilkan lirik di Minecraft. Aplikasi tetap membaca lagu.", 12f, GRAY)
                .apply { setPadding(0, dp(6), 0, 0) })
        }
        val cTool = card("Alat").also { c ->
            c.addView(row(
                btn("Lepas batas baterai") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) },
                btn("Info aplikasi") {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                }))
        }
        val cHelp = card("Cara pakai").also { c ->
            c.addView(label(
                "1. Beri izin notifikasi (tombol di Beranda).\n" +
                "2. Di Minecraft: aktifkan cheat, matikan \"Wajibkan WebSocket terenkripsi\".\n" +
                "3. Ketik di chat: $connectCmd\n" +
                "4. Putar lagu di Spotify. Lirik muncul otomatis.\n" +
                "5. Pengaturan gaya teks ada di menu add-on (jongkok 3x).", 13f, Color.WHITE))
        }

        pages = listOf(
            page("Lyrics Bridge", cQuick, cStatus, cNow),
            page("Lirik", cSync, cLyr),
            page("Setelan", cSet, cTool, cHelp))

        val content = FrameLayout(this).also { f -> pages.forEach { f.addView(it) } }

        // === Navigasi bawah ===
        tabs = listOf("⌂" to "Beranda", "♫" to "Lirik", "⚙" to "Setelan").map { (ic, n) ->
            TextView(this).apply {
                text = "$ic\n$n"; gravity = Gravity.CENTER; textSize = 11f
                setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(8))
            }
        }
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = round(0x33FFFFFF, 28, 0x33FFFFFF)
            setPadding(dp(6), dp(4), dp(6), dp(4))
            tabs.forEachIndexed { i, t ->
                addView(t, LinearLayout.LayoutParams(0, -2, 1f))
                t.setOnClickListener { show(i) }
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#1B1D22"), Color.parseColor("#0B0C0E")))
            addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(nav, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(6), dp(14), dp(12)) })
        }
        setContentView(root)
        show(0)
    }

    private fun show(i: Int) {
        pages.forEachIndexed { k, p -> p.visibility = if (k == i) View.VISIBLE else View.GONE }
        tabs.forEachIndexed { k, t -> t.background = if (k == i) round(0x55FFFFFF, 22) else null }
    }

    // ---------- perbarui isi layar tiap 0,5 detik ----------
    private val loop = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 500) }
    }

    override fun onResume() { super.onResume(); h.post(loop) }
    override fun onPause() { h.removeCallbacks(loop); super.onPause() }

    private fun refresh() {
        val notif = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        val mc = State.clients > 0
        val has = State.title.isNotEmpty()

        mark(ck[0], notif, "Beri izin akses notifikasi")
        mark(ck[1], mc, "Sambungkan Minecraft ($connectCmd)")
        mark(ck[2], has, "Putar lagu di Spotify")
        mark(ck[3], State.lyricsState == 2, "Lirik ditemukan")

        dot(stN, notif, if (notif) "Akses notifikasi aktif" else "Akses notifikasi belum aktif")
        when {
            !notif -> dot(stS, false, "Server belum jalan (aktifkan izin dulu)")
            State.serverUp -> dot(stS, true, "Server siap di 127.0.0.1:${BridgeService.PORT}")
            else -> dot(stS, null, "Server sedang dimulai…")
        }
        if (mc) dot(stM, true, "Minecraft terhubung") else dot(stM, null, "Minecraft belum terhubung (ketik $connectCmd)")

        npTitle.text = if (has) State.title else "(belum ada lagu)"
        npArtist.text = if (has) State.artist else "Putar lagu di Spotify"
        if (art.tag !== State.art) { art.setImageBitmap(State.art); art.tag = State.art }
        npBar.max = (State.dur * 10).toInt().coerceAtLeast(1)
        npBar.progress = (State.pos * 10).toInt().coerceIn(0, npBar.max)
        npTime.text = "${mmss(State.pos)} / ${mmss(State.dur)}"

        offLabel.text = "Geser: ${"%+.1f".format(Locale.US, State.offset)} detik"
        val txt = when (State.lyricsState) {
            1 -> "Mencari lirik…"
            2 -> State.lyrics
            3 -> "Lirik tidak ditemukan untuk lagu ini. Coba \"Cari lirik ulang\" di Beranda."
            else -> "Belum ada lirik."
        }
        if (lyricsView.text.toString() != txt) lyricsView.text = txt
    }
}
