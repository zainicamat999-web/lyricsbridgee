package com.lyricsbridge

import android.content.Context
import android.graphics.Bitmap

/** Status bersama antara service (BridgeService) dan layar (MainActivity). */
object State {
    @Volatile var serverUp = false
    @Volatile var clients = 0
    @Volatile var title = ""
    @Volatile var artist = ""
    @Volatile var pos = 0.0
    @Volatile var dur = 0.0
    @Volatile var playing = false
    @Volatile var art: Bitmap? = null
    @Volatile var lyricsState = 0 // 0 kosong, 1 mencari, 2 ketemu, 3 tidak ketemu
    @Volatile var lyrics = ""
    @Volatile var refetch = false
    @Volatile var sendOn = true
    @Volatile var offset = 0.0

    fun load(c: Context) {
        val p = c.getSharedPreferences("s", 0)
        sendOn = p.getBoolean("send", true)
        offset = p.getFloat("off", 0f).toDouble()
    }

    fun save(c: Context) {
        c.getSharedPreferences("s", 0).edit().putBoolean("send", sendOn).putFloat("off", offset.toFloat()).apply()
    }
}
